import google.generativeai as genai
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from googletrans import Translator
import pickle
import numpy as np
import pandas as pd
import re
import json
from datetime import datetime
import sys

class KannadaNewsPredictor:
    def __init__(self, model_path, tokenizer_path, config_path, gemini_api_key):
        """
        Initialize the combined predictor with LSTM model and Gemini AI
        """
        # Load trained LSTM model
        self.lstm_model = load_model(model_path)
        with open(tokenizer_path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        with open(config_path, 'rb') as f:
            self.config = pickle.load(f)
        
        # Initialize translator with proper settings
        self.translator = Translator()
        
        # Initialize Gemini AI
        genai.configure(api_key=gemini_api_key)
        self.gemini_model = genai.GenerativeModel('gemini-2.0-flash')
        
        self.analysis_history = []
    
    def translate_kannada_to_english(self, kannada_text):
        """
        Translate Kannada text to English with proper encoding
        """
        try:
            # Try translation with timeout
            translation = self.translator.translate(kannada_text, src='kn', dest='en')
            
            if translation and hasattr(translation, 'text'):
                return translation.text
            else:
                return "Translation failed"
                
        except Exception as e:
            print(f"Translation error: {str(e)}")
            return "Translation unavailable"
    
    def preprocess_text(self, text):
        """
        Clean and preprocess text
        """
        text = str(text)
        # Remove special characters but keep letters and spaces
        text = re.sub(r'[^a-zA-Z\s]', ' ', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text.strip().lower()
    
    def predict_with_lstm(self, english_text):
        """
        Predict using trained LSTM model
        """
        # Preprocess text
        cleaned_text = self.preprocess_text(english_text)
        
        if len(cleaned_text) < 5:
            return 0.5, "Text too short for reliable prediction"
        
        # Convert to sequence
        sequence = self.tokenizer.texts_to_sequences([cleaned_text])
        
        if not sequence or len(sequence[0]) == 0:
            return 0.5, "Text not recognizable by model"
        
        # Pad sequence
        padded_sequence = pad_sequences(
            sequence, 
            maxlen=self.config['max_len'], 
            padding='post', 
            truncating='post'
        )
        
        # Make prediction
        prediction = self.lstm_model.predict(padded_sequence, verbose=0)[0][0]
        
        return prediction, "LSTM prediction successful"
    
    def analyze_with_gemini(self, english_text, kannada_text):
        """
        Analyze news with Gemini AI for fake news detection and categorization
        """
        # If translation failed, use a different approach
        if "unavailable" in english_text.lower() or "failed" in english_text.lower():
            prompt = f"""
            Analyze this Kannada news text directly and provide ONLY JSON output:

            KANNADA TEXT: "{kannada_text}"

            Since translation failed, analyze the Kannada text directly if you can understand it.
            If you cannot understand Kannada, make your best guess based on common patterns.

            Provide analysis in this EXACT JSON format:
            {{
                "fake_news": {{
                    "is_fake": true/false,
                    "confidence": 0.0-1.0,
                    "reason": "brief explanation"
                }},
                "category": {{
                    "primary": "entertainment/sports/tech/other",
                    "confidence": 0.0-1.0,
                    "reason": "why this category"
                }},
                "summary": "one line summary of what this might be about",
                "translation_quality": "failed"
            }}
            """
        else:
            prompt = f"""
            Analyze this news text and provide ONLY JSON output:

            KANNADA TEXT: "{kannada_text}"
            ENGLISH TRANSLATION: "{english_text}"

            Provide analysis in this EXACT JSON format:
            {{
                "fake_news": {{
                    "is_fake": true/false,
                    "confidence": 0.0-1.0,
                    "reason": "brief explanation"
                }},
                "category": {{
                    "primary": "entertainment/sports/tech/other",
                    "confidence": 0.0-1.0,
                    "reason": "why this category"
                }},
                "summary": "one line summary of the news in English",
                "translation_quality": "good/poor"
            }}
            """
        
        try:
            response = self.gemini_model.generate_content(prompt)
            return self._parse_gemini_response(response.text)
        except Exception as e:
            print(f"Gemini analysis error: {e}")
            return self._get_default_gemini_analysis()
    
    def _parse_gemini_response(self, response_text):
        """
        Parse Gemini AI response
        """
        try:
            cleaned_response = response_text.strip()
            # Remove markdown code blocks
            if cleaned_response.startswith('```json'):
                cleaned_response = cleaned_response[7:]
            if cleaned_response.endswith('```'):
                cleaned_response = cleaned_response[:-3]
            cleaned_response = cleaned_response.strip()
            
            return json.loads(cleaned_response)
        except json.JSONDecodeError as e:
            print(f"JSON parsing error. Response: {response_text[:100]}...")
            return self._get_default_gemini_analysis()
    
    def _get_default_gemini_analysis(self):
        """
        Default analysis when Gemini fails
        """
        return {
            "fake_news": {
                "is_fake": False,
                "confidence": 0.5,
                "reason": "Analysis unavailable"
            },
            "category": {
                "primary": "other",
                "confidence": 0.5,
                "reason": "Analysis unavailable"
            },
            "summary": "Unable to analyze content",
            "translation_quality": "failed"
        }
    
    def combined_analysis(self, kannada_text):
        """
        Perform combined analysis using translation, LSTM, and Gemini
        """
        print("Translating Kannada to English...")
        english_text = self.translate_kannada_to_english(kannada_text)
        
        print("Analyzing with LSTM model...")
        lstm_prediction, lstm_status = self.predict_with_lstm(english_text)
        
        print("Analyzing with Gemini AI...")
        gemini_analysis = self.analyze_with_gemini(english_text, kannada_text)
        
        # Combine results
        final_prediction = self._combine_predictions(lstm_prediction, gemini_analysis, english_text)
        
        # Store analysis
        analysis_record = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'kannada_text': kannada_text,
            'english_translation': english_text,
            'lstm_prediction': lstm_prediction,
            'gemini_analysis': gemini_analysis,
            'final_prediction': final_prediction
        }
        self.analysis_history.append(analysis_record)
        
        return final_prediction, english_text
    
    def _combine_predictions(self, lstm_prediction, gemini_analysis, english_text):
        """
        Combine LSTM and Gemini predictions intelligently
        """
        # LSTM gives probability of being fake (0-1)
        lstm_fake_prob = lstm_prediction
        
        # Gemini gives binary is_fake with confidence
        gemini_is_fake = gemini_analysis['fake_news']['is_fake']
        gemini_confidence = gemini_analysis['fake_news']['confidence']
        
        # Check if translation worked
        translation_worked = "unavailable" not in english_text.lower() and "failed" not in english_text.lower()
        
        if translation_worked and gemini_confidence > 0.7:
            # High confidence Gemini with working translation
            final_is_fake = gemini_is_fake
            method = "gemini_high_confidence"
            confidence = gemini_confidence
        elif not translation_worked:
            # Translation failed - rely more on LSTM pattern recognition
            final_is_fake = lstm_fake_prob > 0.6  # Higher threshold for fake when translation fails
            method = "lstm_fallback"
            confidence = lstm_fake_prob if final_is_fake else 1 - lstm_fake_prob
        else:
            # Medium case - combine both
            gemini_weight = gemini_confidence * 0.6
            lstm_weight = 1 - gemini_weight
            
            gemini_fake_prob = 0.8 if gemini_is_fake else 0.2
            combined_prob = (gemini_fake_prob * gemini_weight) + (lstm_fake_prob * lstm_weight)
            final_is_fake = combined_prob > 0.5
            method = "combined_analysis"
            confidence = combined_prob if final_is_fake else 1 - combined_prob
        
        return {
            'is_fake': final_is_fake,
            'confidence': min(confidence, 0.95),
            'category': gemini_analysis['category']['primary'],
            'category_confidence': gemini_analysis['category']['confidence'],
            'summary': gemini_analysis['summary'],
            'analysis_method': method,
            'gemini_reason': gemini_analysis['fake_news']['reason'],
            'category_reason': gemini_analysis['category']['reason'],
            'translation_quality': gemini_analysis.get('translation_quality', 'unknown')
        }

def safe_print(text):
    """
    Safely print text that might contain special characters
    """
    try:
        print(text)
    except UnicodeEncodeError:
        # Replace problematic characters
        safe_text = text.encode('utf-8', 'replace').decode('utf-8')
        print(safe_text)

def display_results(kannada_text, english_text, prediction):
    """
    Display analysis results in a formatted way
    """
    safe_print("\n" + "="*80)
    safe_print("KANNADA NEWS ANALYSIS RESULTS")
    safe_print("="*80)
    
    safe_print(f"KANNADA TEXT: {kannada_text}")
    safe_print(f"ENGLISH TRANSLATION: {english_text}")
    
    safe_print(f"\nFAKE NEWS DETECTION:")
    status = "FAKE NEWS" if prediction['is_fake'] else "REAL NEWS"
    safe_print(f"   Result: {status}")
    safe_print(f"   Confidence: {prediction['confidence']:.2%}")
    safe_print(f"   Reason: {prediction['gemini_reason']}")
    safe_print(f"   Method: {prediction['analysis_method']}")
    safe_print(f"   Translation Quality: {prediction['translation_quality'].upper()}")
    
    safe_print(f"\nCATEGORY CLASSIFICATION:")
    category_emojis = {
        'entertainment': '[MOVIES]',
        'sports': '[SPORTS]', 
        'tech': '[TECH]',
        'other': '[NEWS]'
    }
    emoji = category_emojis.get(prediction['category'], '[NEWS]')
    safe_print(f"   Category: {emoji} {prediction['category'].upper()}")
    safe_print(f"   Confidence: {prediction['category_confidence']:.2%}")
    safe_print(f"   Reason: {prediction['category_reason']}")
    
    safe_print(f"\nSUMMARY: {prediction['summary']}")
    safe_print("="*80)

def test_translation_simple():
    """
    Simple translation test without complex encoding
    """
    translator = Translator()
    test_texts = [
        "ನಮಸ್ಕಾರ",
        "ಕ್ರಿಕೆಟ್",
        "ತಂತ್ರಜ್ಞಾನ"
    ]
    
    print("TRANSLATION TEST:")
    print("="*30)
    for text in test_texts:
        try:
            translation = translator.translate(text, src='kn', dest='en')
            print(f"Kannada: {text}")
            print(f"English: {translation.text}")
            print("-" * 20)
        except Exception as e:
            print(f"Error: {e}")

def main():
    # Configuration
    MODEL_PATH = 'kannada_news_lstm_model.h5'
    TOKENIZER_PATH = 'tokenizer.pkl'
    CONFIG_PATH = 'model_config.pkl'
    GEMINI_API_KEY = 'AIzaSyBhj6VEH4jGLEdkPtSskE7W1bnr0aCL-YY'
    
    # Simple Kannada news samples (without complex characters)
    sample_kannada_news = [
        "ಕ್ರಿಕೆಟ್‌ನಲ್ಲಿ ಭಾರತ ವಿಶ್ವಕಪ್ ಗೆದ್ದಿತು",
        "ನೂತನ ಐಫೋನ್ ಬಿಡುಗಡೆಯಾಗಿದೆ", 
        "ಸಿನಿಮಾ ಪ್ರದರ್ಶನ ರದ್ದಾಗಿದೆ",
        "ಬಿಟ್‌ಕಾಯಿನ್‌ನಲ್ಲಿ ದೊಡ್ಡ ಏರಿಕೆ",
        "ಕಬಡ್ಡಿ ತಂಡ ಚಾಂಪಿಯನ್‌ಶಿಪ್ ಗೆದ್ದಿತು",
    ]
    
    # Simple test first
    print("Testing basic functionality...")
    test_translation_simple()
    
    try:
        # Initialize predictor
        predictor = KannadaNewsPredictor(
            model_path=MODEL_PATH,
            tokenizer_path=TOKENIZER_PATH,
            config_path=CONFIG_PATH,
            gemini_api_key=GEMINI_API_KEY
        )
        print("Models loaded successfully!")
    except Exception as e:
        print(f"Error loading models: {e}")
        print("Please make sure all model files are available:")
        print("   - kannada_news_lstm_model.h5")
        print("   - tokenizer.pkl")
        print("   - model_config.pkl")
        return
    
    print("\nKANNADA NEWS ANALYSIS SYSTEM")
    print("="*40)
    print("This system analyzes Kannada news using:")
    print("  • Google Translate")
    print("  • Trained LSTM Model") 
    print("  • Gemini AI")
    
    while True:
        print("\n" + "="*40)
        print("OPTIONS:")
        print("1. Analyze custom Kannada news")
        print("2. Analyze sample news")
        print("3. View analysis history") 
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            print("\nEnter Kannada news text:")
            kannada_text = input("Kannada text: ").strip()
            
            if not kannada_text:
                print("Please enter some text.")
                continue
                
            if len(kannada_text) < 5:
                print("Text too short. Please enter more content.")
                continue
            
            try:
                prediction, english_text = predictor.combined_analysis(kannada_text)
                display_results(kannada_text, english_text, prediction)
                
            except Exception as e:
                print(f"Analysis error: {e}")
        
        elif choice == '2':
            print(f"\nAnalyzing {len(sample_kannada_news)} sample news articles...")
            for i, news in enumerate(sample_kannada_news, 1):
                print(f"\n[{i}/{len(sample_kannada_news)}] Analyzing sample news...")
                try:
                    prediction, english_text = predictor.combined_analysis(news)
                    display_results(news, english_text, prediction)
                except Exception as e:
                    print(f"Error analyzing sample {i}: {e}")
        
        elif choice == '3':
            if not predictor.analysis_history:
                print("No analysis history available.")
            else:
                print(f"\nANALYSIS HISTORY (Total: {len(predictor.analysis_history)})")
                print("="*50)
                for i, analysis in enumerate(predictor.analysis_history, 1):
                    pred = analysis['final_prediction']
                    status = "FAKE" if pred['is_fake'] else "REAL"
                    # Show first 20 characters only
                    text_preview = analysis['kannada_text'][:20] + "..." if len(analysis['kannada_text']) > 20 else analysis['kannada_text']
                    print(f"{i}. [{status}] {pred['category']} - {text_preview}")
        
        elif choice == '4':
            print("Thank you for using Kannada News Analysis System!")
            break
        
        else:
            print("Invalid choice. Please enter 1-4.")

if __name__ == "__main__":
    main()
