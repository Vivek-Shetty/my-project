import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle
import re

class KannadaNewsClassifier:
    def __init__(self, model_path, tokenizer_path, config_path):
        """
        Initialize the classifier with trained model and artifacts
        """
        self.model = load_model(model_path)
        with open(tokenizer_path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        with open(config_path, 'rb') as f:
            self.config = pickle.load(f)
        
    def preprocess_text(self, text):
        """
        Clean and preprocess text
        """
        text = str(text)
        # Remove special characters but keep Kannada characters
        text = re.sub(r'[^\w\s]', ' ', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
        return text.strip().lower()
    
    def predict_news(self, kannada_text):
        """
        Predict whether the news is real or fake
        """
        # Preprocess text
        cleaned_text = self.preprocess_text(kannada_text)
        text_to_predict = cleaned_text
        
        # Convert to sequence
        sequence = self.tokenizer.texts_to_sequences([text_to_predict])
        
        if not sequence or len(sequence[0]) == 0:
            return "UNKNOWN", 0.5, "Text too short or not recognizable"
        
        # Pad sequence
        padded_sequence = pad_sequences(
            sequence, 
            maxlen=self.config['max_len'], 
            padding='post', 
            truncating='post'
        )
        
        # Make prediction
        prediction = self.model.predict(padded_sequence, verbose=0)[0][0]
        
        # Interpret result
        if prediction > 0.5:
            result = "FAKE NEWS"
            confidence = prediction
        else:
            result = "REAL NEWS"
            confidence = 1 - prediction
        
        return result, confidence, text_to_predict

def main():
    # Initialize classifier
    try:
        classifier = KannadaNewsClassifier(
            model_path='kannada_news_lstm_model.h5',
            tokenizer_path='tokenizer.pkl',
            config_path='model_config.pkl'
        )
        print("✅ Model loaded successfully!")
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        print("Please make sure all model files are in the current directory:")
        print("   - kannada_news_lstm_model.h5")
        print("   - tokenizer.pkl") 
        print("   - model_config.pkl")
        return
    
    # Interactive prediction loop
    print("\n" + "="*60)
    print("🔍 KANNADA NEWS FAKE DETECTION SYSTEM")
    print("="*60)
    print("Enter Kannada news text for classification")
    print("Type 'quit' to exit the program")
    
    while True:
        print("\n" + "-"*40)
        user_input = input("📝 Enter Kannada news text: ").strip()
        
        if user_input.lower() in ['quit', 'exit', 'q']:
            print("👋 Thank you for using the system!")
            break
        
        if not user_input:
            print("⚠️ Please enter some text.")
            continue
        
        if len(user_input) < 10:
            print("⚠️ Text too short. Please enter more content.")
            continue
        
        try:
            # Make prediction
            result, confidence, processed_text = classifier.predict_news(user_input)
            
            # Display results with emojis
            print(f"\n🎯 ANALYSIS RESULTS:")
            print(f"   📝 Original Text: {user_input}")
            print(f"   🔍 Prediction: {result}")
            print(f"   📊 Confidence: {confidence:.2%}")
            
            # Additional interpretation
            if confidence > 0.8:
                print("   💡 Note: High confidence prediction")
            elif confidence > 0.6:
                print("   💡 Note: Moderate confidence prediction")
            else:
                print("   💡 Note: Low confidence - manual review recommended")
                
        except Exception as e:
            print(f"❌ Error during prediction: {e}")

if __name__ == "__main__":
    main()
