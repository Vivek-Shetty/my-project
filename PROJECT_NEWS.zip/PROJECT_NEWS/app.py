from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import google.generativeai as genai
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from googletrans import Translator
import pickle
import numpy as np
import re
import json
from datetime import datetime
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

from database import init_db, get_db_connection
from models import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

class KannadaNewsPredictor:
    def __init__(self, model_path, tokenizer_path, config_path, gemini_api_key):
        try:
            self.lstm_model = load_model(model_path)
            with open(tokenizer_path, 'rb') as f:
                self.tokenizer = pickle.load(f)
            with open(config_path, 'rb') as f:
                self.config = pickle.load(f)
            
            self.translator = Translator()
            genai.configure(api_key=gemini_api_key)
            self.gemini_model = genai.GenerativeModel('gemini-2.0-flash')
        except Exception as e:
            print(f"Error initializing predictor: {e}")
            self.lstm_model = None

    def translate_kannada_to_english(self, kannada_text):
        """
        Improved translation function without timeout parameter
        """
        try:
            # Clean the text first
            cleaned_text = kannada_text.strip()
            
            print(f"Original text: {repr(cleaned_text)}")
            print(f"Text length: {len(cleaned_text)}")
            
            # Remove any trailing numbers or special characters that might cause issues
            cleaned_text = re.sub(r'[0-9,]+$', '', cleaned_text).strip()
            
            # Check if text contains valid Kannada characters
            def contains_kannada(text):
                # Unicode range for Kannada
                kannada_range = '\u0C80-\u0CFF'
                if re.search(f'[{kannada_range}]', text):
                    return True
                
                # Check for specific Kannada characters
                kannada_chars = ['ನ', 'ಮ', 'ವ', 'ಲ', 'ಹ', 'ಕ', 'ತ', 'ಪ', 'ಯ', 'ರ', 
                            'ದ', 'ಜ', 'ಡ', 'ಉ', 'ಊ', 'ಎ', 'ಏ', 'ಐ', 'ಒ', 'ಓ',
                            'ಾ', 'ಿ', 'ೀ', 'ು', 'ೂ', 'ೆ', 'ೇ', 'ೈ', 'ೊ', 'ೋ', 'ೌ']
                
                for char in kannada_chars:
                    if char in text:
                        return True
                        
                return False
            
            # Check if text contains Kannada
            if not contains_kannada(cleaned_text):
                print("Text doesn't appear to contain Kannada characters")
                # Still attempt translation as it might be short or mixed text
            
            # Try translation with different approaches
            for attempt in range(3):
                try:
                    print(f"Translation attempt {attempt + 1}")
                    
                    # Method 1: Direct translation without timeout
                    translation = self.translator.translate(
                        cleaned_text, 
                        src='kn', 
                        dest='en'
                    )
                    
                    if translation and hasattr(translation, 'text') and translation.text:
                        translated_text = translation.text.strip()
                        print(f"Translation successful: {translated_text}")
                        
                        # Validate that translation actually worked
                        if (translated_text.lower() != cleaned_text.lower() and 
                            len(translated_text) > 0 and
                            not translated_text.startswith('[') and
                            'failed' not in translated_text.lower()):
                            return translated_text
                        else:
                            print("Translation returned same text or invalid result")
                            continue
                            
                except Exception as e:
                    print(f"Translation attempt {attempt + 1} failed: {e}")
                    # Wait a bit before retry
                    import time
                    time.sleep(1)
                    continue
            
            # If all attempts fail, try with gemini as fallback
            print("Attempting translation with Gemini fallback...")
            try:
                gemini_translation = self._translate_with_gemini(cleaned_text)
                if gemini_translation:
                    return gemini_translation
            except Exception as e:
                print(f"Gemini translation failed: {e}")
            
            return "Translation service unavailable - please try again"
                
        except Exception as e:
            print(f"Translation error: {str(e)}")
            return "Translation service temporarily unavailable"

    def _translate_with_gemini(self, kannada_text):
        """Fallback translation using Gemini"""
        try:
            prompt = f"""
            Translate this Kannada text to English. Return ONLY the English translation, nothing else.
            
            Kannada text: "{kannada_text}"
            
            English translation:
            """
            
            response = self.gemini_model.generate_content(prompt)
            translated = response.text.strip()
            
            # Clean the response
            translated = re.sub(r'^English translation:\s*', '', translated)
            translated = re.sub(r'^Translation:\s*', '', translated)
            translated = translated.strip('"\'')
            
            # Validate response
            if (translated and 
                translated.lower() != kannada_text.lower() and 
                len(translated) > 0 and
                len(translated) > len(kannada_text) * 0.3):  # Reasonable length
                return translated
            else:
                return None
                
        except Exception as e:
            print(f"Gemini translation error: {e}")
            return None

    def preprocess_text(self, text):
        text = str(text)
        text = re.sub(r'[^a-zA-Z\s]', ' ', text)
        text = ' '.join(text.split())
        return text.strip().lower()

    def predict_with_lstm(self, english_text):
        if not self.lstm_model:
            return 0.5, "Model not available"
            
        cleaned_text = self.preprocess_text(english_text)
        if len(cleaned_text) < 5:
            return 0.5, "Text too short for reliable prediction"
        
        sequence = self.tokenizer.texts_to_sequences([cleaned_text])
        if not sequence or len(sequence[0]) == 0:
            return 0.5, "Text not recognizable by model"
        
        padded_sequence = pad_sequences(
            sequence, 
            maxlen=self.config['max_len'], 
            padding='post', 
            truncating='post'
        )
        
        prediction = self.lstm_model.predict(padded_sequence, verbose=0)[0][0]
        return prediction, "LSTM prediction successful"

    def analyze_with_gemini(self, english_text, kannada_text):
        if "unavailable" in english_text.lower() or "failed" in english_text.lower():
            prompt = f"""
            Analyze this Kannada news text directly and provide ONLY JSON output:

            KANNADA TEXT: "{kannada_text}"

            Provide analysis in this EXACT JSON format:
            {{
                "fake_news": {{
                    "is_fake": true/false,
                    "confidence": 0.0-1.0
                }},
                "category": {{
                    "primary": "entertainment/sports/tech/other",
                    "confidence": 0.0-1.0
                }},
                "summary": "one line summary of what this might be about",
                "translation_quality": "failed"
            }}
            """
        else:
            prompt = f"""
            Analyze this news text and provide ONLY JSON output:

            KANNADA TEXT: "{kannada_text}"
            ENGLISH TRANSLATION: "{english_text}"

            Provide analysis in this EXACT JSON format:
            {{
                "fake_news": {{
                    "is_fake": true/fake,
                    "confidence": 0.0-1.0
                }},
                "category": {{
                    "primary": "entertainment/sports/tech/other",
                    "confidence": 0.0-1.0
                }},
                "summary": "one line summary of the news in English",
                "translation_quality": "good/poor"
            }}
            """
        
        try:
            response = self.gemini_model.generate_content(prompt)
            return self._parse_gemini_response(response.text)
        except Exception as e:
            print(f"Gemini analysis error: {e}")
            return self._get_default_gemini_analysis()

    def _parse_gemini_response(self, response_text):
        try:
            cleaned_response = response_text.strip()
            if cleaned_response.startswith('```json'):
                cleaned_response = cleaned_response[7:]
            if cleaned_response.endswith('```'):
                cleaned_response = cleaned_response[:-3]
            cleaned_response = cleaned_response.strip()
            
            return json.loads(cleaned_response)
        except json.JSONDecodeError as e:
            print(f"JSON parsing error. Response: {response_text[:100]}...")
            return self._get_default_gemini_analysis()

    def _get_default_gemini_analysis(self):
        return {
            "fake_news": {
                "is_fake": False,
                "confidence": 0.5
            },
            "category": {
                "primary": "other",
                "confidence": 0.5
            },
            "summary": "Unable to analyze content",
            "translation_quality": "failed"
        }

    def combined_analysis(self, kannada_text):
        english_text = self.translate_kannada_to_english(kannada_text)
        lstm_prediction, lstm_status = self.predict_with_lstm(english_text)
        gemini_analysis = self.analyze_with_gemini(english_text, kannada_text)
        
        final_prediction = self._combine_predictions(lstm_prediction, gemini_analysis, english_text)
        return final_prediction, english_text

    def _combine_predictions(self, lstm_prediction, gemini_analysis, english_text):
        lstm_fake_prob = lstm_prediction
        gemini_is_fake = gemini_analysis['fake_news']['is_fake']
        gemini_confidence = gemini_analysis['fake_news']['confidence']
        
        translation_worked = "unavailable" not in english_text.lower() and "failed" not in english_text.lower()
        
        if translation_worked and gemini_confidence > 0.7:
            final_is_fake = gemini_is_fake
            method = "gemini_high_confidence"
            confidence = gemini_confidence
        elif not translation_worked:
            final_is_fake = lstm_fake_prob > 0.6
            method = "lstm_fallback"
            confidence = lstm_fake_prob if final_is_fake else 1 - lstm_fake_prob
        else:
            gemini_weight = gemini_confidence * 0.6
            lstm_weight = 1 - gemini_weight
            
            gemini_fake_prob = 0.8 if gemini_is_fake else 0.2
            combined_prob = (gemini_fake_prob * gemini_weight) + (lstm_fake_prob * lstm_weight)
            final_is_fake = combined_prob > 0.5
            method = "combined_analysis"
            confidence = combined_prob if final_is_fake else 1 - combined_prob
        
        return {
            'is_fake': final_is_fake,
            'confidence': min(confidence, 0.95),
            'category': gemini_analysis['category']['primary'],
            'category_confidence': gemini_analysis['category']['confidence'],
            'summary': gemini_analysis['summary'],
            'analysis_method': method,
            'translation_quality': gemini_analysis.get('translation_quality', 'unknown')
        }

# Initialize predictor
predictor = KannadaNewsPredictor(
    model_path='kannada_news_lstm_model.h5',
    tokenizer_path='tokenizer.pkl',
    config_path='model_config.pkl',
    gemini_api_key='AIzaSyBhj6VEH4jGLEdkPtSskE7W1bnr0aCL-YY'
)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        existing_user = conn.execute(
            'SELECT id FROM users WHERE username = ? OR email = ?', 
            (username, email)
        ).fetchone()
        
        if existing_user:
            flash('Username or email already exists')
            return render_template('register.html')
        
        password_hash = generate_password_hash(password)
        conn.execute(
            'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
            (username, email, password_hash)
        )
        conn.commit()
        conn.close()
        
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        user_data = conn.execute(
            'SELECT * FROM users WHERE username = ?', (username,)
        ).fetchone()
        conn.close()
        
        if user_data and check_password_hash(user_data['password_hash'], password):
            user = User(id=user_data['id'], username=user_data['username'], email=user_data['email'])
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    history = conn.execute(
        '''SELECT * FROM analysis_history 
           WHERE user_id = ? 
           ORDER BY created_at DESC LIMIT 10''',
        (current_user.id,)
    ).fetchall()
    conn.close()
    
    return render_template('dashboard.html', history=history)

@app.route('/analyze', methods=['POST'])
@login_required
def analyze():
    kannada_text = request.form['kannada_text']
    
    if not kannada_text or len(kannada_text.strip()) < 5:
        flash('Please enter valid Kannada text (minimum 5 characters)')
        return redirect(url_for('dashboard'))
    
    try:
        prediction, english_text = predictor.combined_analysis(kannada_text.strip())
        
        # Save to database
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO analysis_history 
               (user_id, kannada_text, english_translation, is_fake, confidence, 
                category, category_confidence, summary, analysis_method, translation_quality)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (current_user.id, kannada_text, english_text, prediction['is_fake'], 
             prediction['confidence'], prediction['category'], prediction['category_confidence'],
             prediction['summary'], prediction['analysis_method'], prediction['translation_quality'])
        )
        conn.commit()
        conn.close()
        
        return render_template('result.html', 
                             kannada_text=kannada_text,
                             english_text=english_text,
                             prediction=prediction)
    
    except Exception as e:
        flash(f'Analysis error: {str(e)}')
        return redirect(url_for('dashboard'))

@app.route('/api/translate', methods=['POST'])
@login_required
def translate_text():
    """API endpoint for real-time translation"""
    data = request.get_json()
    kannada_text = data.get('text', '').strip()
    
    print(f"Received translation request: {repr(kannada_text)}")
    
    if not kannada_text:
        return jsonify({'error': 'No text provided'}), 400
    
    if len(kannada_text) < 2:
        return jsonify({
            'kannada_text': kannada_text,
            'english_translation': 'Please enter more text for translation',
            'quality': 'poor'
        })
    
    try:
        english_text = predictor.translate_kannada_to_english(kannada_text)
        
        # Determine translation quality
        quality = 'good'
        if any(word in english_text.lower() for word in ['unable', 'failed', 'error', 'unavailable', 'try again']):
            quality = 'poor'
        elif len(english_text) < len(kannada_text) * 0.3:
            quality = 'fair'
        elif english_text.lower() == kannada_text.lower():
            quality = 'poor'
        
        return jsonify({
            'kannada_text': kannada_text,
            'english_translation': english_text,
            'quality': quality
        })
        
    except Exception as e:
        print(f"Translation API error: {e}")
        return jsonify({
            'kannada_text': kannada_text,
            'english_translation': 'Translation service temporarily unavailable',
            'quality': 'poor'
        })
if __name__ == '__main__':
    init_db()
    app.run(debug=True)